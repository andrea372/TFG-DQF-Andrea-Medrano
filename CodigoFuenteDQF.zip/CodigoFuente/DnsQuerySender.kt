package com.tfg.dqfapp

import android.util.Log

data class DnsQueryResult(
    val domain: String,
    val success: Boolean
)

object DnsQuerySender {

    fun sendQuery(
        mode: String,
        qpm: Int? = null,
        jitterMs: Long? = null
    ): DnsQueryResult {
        val domain = DomainList.getRandomDomain()
        val client = DotDnsClient()
        val wasSent = client.sendQuery(domain)

        QueryLog.add(
            mode = mode,
            domain = domain,
            success = wasSent,
            qpm = qpm,
            jitterMs = jitterMs
        )

        Log.d("DQF_QUERY", "DoT sent=$wasSent mode=$mode domain=$domain")

        return DnsQueryResult(
            domain = domain,
            success = wasSent
        )
    }

    fun sendSingleQuery(): String {
        val result = sendQuery(mode = "manual")

        return if (result.success) {
            "DoT enviada: ${result.domain}"
        } else {
            "DoT fallida: ${result.domain}"
        }
    }
}