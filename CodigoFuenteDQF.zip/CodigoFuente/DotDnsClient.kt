package com.tfg.dqfapp

import android.util.Log
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyStore
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManagerFactory
import kotlin.random.Random

class DotDnsClient(
    private val serverIp: String = "8.8.8.8",
    private val serverPort: Int = 853,
    private val serverName: String = "dns.google",
    private val timeoutMs: Int = 7000
) {

    fun sendQuery(domain: String): Boolean {
        val dnsPacket = buildDnsPacket(domain)

        return try {
            val socketFactory = getSocketFactory()

            val tcpSocket = Socket()
            tcpSocket.connect(InetSocketAddress(serverIp, serverPort), timeoutMs)

            val tlsSocket = socketFactory.createSocket(
                tcpSocket,
                serverName,
                serverPort,
                true
            ) as SSLSocket

            tlsSocket.soTimeout = timeoutMs
            tlsSocket.startHandshake()

            val output = DataOutputStream(tlsSocket.outputStream)
            val input = DataInputStream(tlsSocket.inputStream)

            output.writeShort(dnsPacket.size)
            output.write(dnsPacket)
            output.flush()

            val answerSize = input.readUnsignedShort()
            input.readFully(ByteArray(answerSize))

            tlsSocket.close()
            true
        } catch (e: Exception) {
            Log.e("DOT", "Error enviando consulta DoT", e)
            false
        }
    }

    internal fun buildDnsPacket(domain: String): ByteArray {
        val packet = ByteArray(512)
        var pos = 0

        val id = Random.nextInt(0, 65536)
        packet[pos++] = (id shr 8).toByte()
        packet[pos++] = id.toByte()

        packet[pos++] = 0x01
        packet[pos++] = 0x00
        packet[pos++] = 0x00
        packet[pos++] = 0x01
        packet[pos++] = 0x00
        packet[pos++] = 0x00
        packet[pos++] = 0x00
        packet[pos++] = 0x00
        packet[pos++] = 0x00
        packet[pos++] = 0x00

        for (part in domain.split(".")) {
            packet[pos++] = part.length.toByte()

            for (letter in part) {
                packet[pos++] = letter.code.toByte()
            }
        }

        packet[pos++] = 0x00
        packet[pos++] = 0x00
        packet[pos++] = 0x01
        packet[pos++] = 0x00
        packet[pos++] = 0x01

        return packet.copyOfRange(0, pos)
    }

    private fun getSocketFactory(): SSLSocketFactory {
        val keyStore = KeyStore.getInstance("AndroidCAStore")
        keyStore.load(null)

        val trustFactory = TrustManagerFactory.getInstance(
            TrustManagerFactory.getDefaultAlgorithm()
        )
        trustFactory.init(keyStore)

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, trustFactory.trustManagers, null)

        return sslContext.socketFactory
    }
}