package com.tfg.dqfapp

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class QueryLogEntry(
    val timestamp: String,
    val mode: String,
    val domain: String,
    val success: Boolean,
    val qpm: Int?,
    val jitterMs: Long?
)

object QueryLog {

    private const val MAX_ENTRIES = 500

    private val entries = mutableListOf<QueryLogEntry>()

    @Synchronized
    fun add(
        mode: String,
        domain: String,
        success: Boolean,
        qpm: Int? = null,
        jitterMs: Long? = null
    ) {
        entries.add(
            QueryLogEntry(
                timestamp = currentTime(),
                mode = mode,
                domain = domain,
                success = success,
                qpm = qpm,
                jitterMs = jitterMs
            )
        )

        if (entries.size > MAX_ENTRIES) {
            entries.removeAt(0)
        }
    }

    @Synchronized
    fun latestText(maxItems: Int = 8): String {
        if (entries.isEmpty()) {
            return "Sin consultas registradas"
        }

        return entries
            .takeLast(maxItems)
            .joinToString("\n") { entry ->
                val result = if (entry.success) "OK" else "ERROR"
                val qpmText = entry.qpm?.toString() ?: "-"
                val jitterText = entry.jitterMs?.toString() ?: "-"

                "${entry.timestamp} | ${entry.mode} | ${entry.domain} | $result | qpm=$qpmText | jitter=$jitterText"
            }
    }

    @Synchronized
    fun toCsv(): String {
        val header = "timestamp,mode,domain,success,qpm,jitter_ms"

        val rows = entries.joinToString("\n") { entry ->
            val result = if (entry.success) "OK" else "ERROR"
            val qpmText = entry.qpm?.toString() ?: "-"
            val jitterText = entry.jitterMs?.toString() ?: "-"

            "${entry.timestamp},${entry.mode},${entry.domain},$result,$qpmText,$jitterText"
        }

        return if (rows.isBlank()) header else "$header\n$rows"
    }

    @Synchronized
    fun total(): Int {
        return entries.size
    }

    @Synchronized
    fun clear() {
        entries.clear()
    }

    private fun currentTime(): String {
        return SimpleDateFormat(
            "yyyy-MM-dd HH:mm:ss.SSS",
            Locale.US
        ).format(Date())
    }
}