package com.tfg.dqfapp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DQFUnitTest {

    @Test
    fun allDomainsHaveBasicFormat() {
        val domains = DomainList.getAllDomains()

        assertTrue(domains.isNotEmpty())

        for (domain in domains) {
            assertTrue(domain.isNotBlank())
            assertTrue(domain.contains("."))
            assertTrue(domain.startsWith(".").not())
            assertTrue(domain.endsWith(".").not())
        }
    }

    @Test
    fun queryLogStoresEntriesAndExportsCsv() {
        QueryLog.clear()

        QueryLog.add(
            mode = "manual",
            domain = "google.com",
            success = true,
            qpm = null,
            jitterMs = null
        )

        assertEquals(1, QueryLog.total())

        val csv = QueryLog.toCsv()

        assertTrue(csv.contains("timestamp,mode,domain,success,qpm,jitter_ms"))
        assertTrue(csv.contains("manual"))
        assertTrue(csv.contains("google.com"))
        assertTrue(csv.contains("OK"))
    }

    @Test
    fun dnsPacketContainsDomainParts() {
        val client = DotDnsClient()
        val packet = client.buildDnsPacket("google.com")

        assertTrue(packet.isNotEmpty())
        assertTrue(packet.contains(6.toByte()))
        assertTrue(packet.contains(3.toByte()))

        val readableText = packet
            .filter { byte -> byte in 32..126 }
            .map { byte -> byte.toInt().toChar() }
            .joinToString("")

        assertTrue(readableText.contains("google"))
        assertTrue(readableText.contains("com"))
    }
}