package com.tfg.dqfapp

import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
import com.tfg.dqfapp.ui.theme.DQFAppTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            DQFAppTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { padding ->
                    DQFHomeScreen(
                        modifier = Modifier.padding(padding)
                    )
                }
            }
        }
    }
}

@Composable
fun DQFHomeScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var qpmText by remember { mutableStateOf("30") }
    var jitterText by remember { mutableStateOf("500") }
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("-") }
    var logText by remember { mutableStateOf(QueryLog.latestText()) }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(receivedContext: Context?, intent: Intent?) {
                if (intent?.action != DnsForegroundService.ACTION_QUERY_SENT) {
                    return
                }

                val domain = intent.getStringExtra(DnsForegroundService.EXTRA_DOMAIN) ?: "-"
                val ok = intent.getBooleanExtra(DnsForegroundService.EXTRA_SUCCESS, false)
                val total = intent.getIntExtra(DnsForegroundService.EXTRA_TOTAL_QUERIES, 0)

                status = if (ok) {
                    "Auto DoT: $domain - total: $total"
                } else {
                    "Auto DoT fallida: $domain - total: $total"
                }

                logText = QueryLog.latestText()
            }
        }

        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(DnsForegroundService.ACTION_QUERY_SENT),
            RECEIVER_NOT_EXPORTED
        )

        onDispose {
            context.unregisterReceiver(receiver)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Text(
            text = "DQF App",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Configuración",
            style = MaterialTheme.typography.titleMedium
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = qpmText,
            onValueChange = { qpmText = it },
            label = { Text("Queries per minute") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = jitterText,
            onValueChange = { jitterText = it },
            label = { Text("Jitter (ms)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    val qpm = qpmText.toIntOrNull()?.coerceAtLeast(1) ?: 30
                    val jitter = jitterText.toLongOrNull()?.coerceAtLeast(0L) ?: 500L

                    val serviceIntent = Intent(context, DnsForegroundService::class.java).apply {
                        putExtra(DnsForegroundService.EXTRA_QPM, qpm)
                        putExtra(DnsForegroundService.EXTRA_JITTER_MS, jitter)
                    }

                    ContextCompat.startForegroundService(context, serviceIntent)

                    running = true
                    status = "Servicio iniciado: $qpm qpm, jitter ${jitter}ms"
                    logText = QueryLog.latestText()
                },
                enabled = !running,
                modifier = Modifier.weight(1f)
            ) {
                Text("Start auto")
            }

            Button(
                onClick = {
                    val serviceIntent = Intent(context, DnsForegroundService::class.java)
                    context.stopService(serviceIntent)

                    running = false
                    status = "Servicio detenido"
                    logText = QueryLog.latestText()
                },
                enabled = running,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFC75B5B),
                    contentColor = Color.White,
                    disabledContainerColor = Color.LightGray,
                    disabledContentColor = Color.DarkGray
                ),
                modifier = Modifier.weight(1f)
            ) {
                Text("Stop")
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = {
                status = "Enviando consulta DoT..."

                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        DnsQuerySender.sendSingleQuery()
                    }

                    status = result
                    logText = QueryLog.latestText()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Send manual query")
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Estado: $status",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Registro",
            style = MaterialTheme.typography.titleMedium
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val csv = QueryLog.toCsv()

                    val internalFile = File(context.filesDir, CSV_FILE_NAME)
                    internalFile.writeText(csv)

                    val exportedFile = saveCsvInDownloads(context, csv)

                    status = if (exportedFile != null) {
                        "CSV exportado: $exportedFile"
                    } else {
                        "CSV guardado interno: ${internalFile.name}"
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Export CSV")
            }

            Button(
                onClick = {
                    QueryLog.clear()
                    logText = QueryLog.latestText()
                    status = "Registro limpiado"
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Clear log")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(
                    width = 1.dp,
                    color = Color.LightGray
                )
                .padding(10.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = logText,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun saveCsvInDownloads(
    context: Context,
    csv: String
): String? {
    val fileName = buildCsvFileName()

    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }

            val uri = context.contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values
            ) ?: return null

            context.contentResolver.openOutputStream(uri)?.use { stream ->
                stream.write(csv.toByteArray())
            }

            fileName
        } else {
            val folder = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS
            )

            if (!folder.exists()) {
                folder.mkdirs()
            }

            File(folder, fileName).writeText(csv)
            fileName
        }
    } catch (_: Exception) {
        null
    }
}

private fun buildCsvFileName(): String {
    val time = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    return "DQF_query_log_$time.csv"
}

private const val CSV_FILE_NAME = "DQF_query_log.csv"

@Preview(showBackground = true)
@Composable
fun DQFHomeScreenPreview() {
    DQFAppTheme {
        DQFHomeScreen()
    }
}