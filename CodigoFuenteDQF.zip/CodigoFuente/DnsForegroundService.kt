package com.tfg.dqfapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

class DnsForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var queryJob: Job? = null
    private var queryCount = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val qpm = intent?.getIntExtra(EXTRA_QPM, DEFAULT_QPM) ?: DEFAULT_QPM
        val jitter = intent?.getLongExtra(EXTRA_JITTER_MS, DEFAULT_JITTER_MS) ?: DEFAULT_JITTER_MS

        val finalQpm = qpm.coerceAtLeast(1)
        val finalJitter = jitter.coerceAtLeast(0L)
        val baseDelay = ONE_MINUTE_MS / finalQpm

        queryCount = QueryLog.total()

        startForeground(
            NOTIFICATION_ID,
            buildNotification("DoT auto: $finalQpm qpm, jitter ${finalJitter}ms")
        )

        startQueryLoop(
            baseDelayMs = baseDelay,
            jitterMs = finalJitter,
            qpm = finalQpm
        )

        return START_STICKY
    }

    override fun onDestroy() {
        queryJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun startQueryLoop(
        baseDelayMs: Long,
        jitterMs: Long,
        qpm: Int
    ) {
        queryJob?.cancel()

        queryJob = scope.launch {
            while (true) {
                val result = DnsQuerySender.sendQuery(
                    mode = "auto",
                    qpm = qpm,
                    jitterMs = jitterMs
                )

                queryCount += 1

                Log.d(
                    "DQF_SERVICE",
                    "AUTO DoT sent=${result.success} domain=${result.domain}"
                )

                updateNotification(result.domain, result.success, queryCount)
                sendUpdateToActivity(result.domain, result.success, queryCount)

                val waitTime = getNextDelay(baseDelayMs, jitterMs)
                Log.d("DQF_SERVICE", "Next query delayMs=$waitTime")

                delay(waitTime)
            }
        }
    }

    private fun getNextDelay(baseDelayMs: Long, jitterMs: Long): Long {
        return if (jitterMs == 0L) {
            baseDelayMs
        } else {
            val variation = Random.nextLong(-jitterMs, jitterMs + 1)
            (baseDelayMs + variation).coerceAtLeast(MIN_DELAY_MS)
        }
    }

    private fun updateNotification(
        domain: String,
        success: Boolean,
        total: Int
    ) {
        val text = if (success) {
            "Ultima DoT: $domain - total: $total"
        } else {
            "Ultima DoT fallida: $domain - total: $total"
        }

        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DQF App activa")
            .setContentText(text)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .build()
    }

    private fun sendUpdateToActivity(
        domain: String,
        success: Boolean,
        total: Int
    ) {
        val intent = Intent(ACTION_QUERY_SENT).apply {
            setPackage(packageName)
            putExtra(EXTRA_DOMAIN, domain)
            putExtra(EXTRA_SUCCESS, success)
            putExtra(EXTRA_TOTAL_QUERIES, total)
        }

        sendBroadcast(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DQF background service",
                NotificationManager.IMPORTANCE_LOW
            )

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val EXTRA_QPM = "extra_qpm"
        const val EXTRA_JITTER_MS = "extra_jitter_ms"

        const val ACTION_QUERY_SENT = "com.tfg.dqfapp.ACTION_QUERY_SENT"
        const val EXTRA_DOMAIN = "extra_domain"
        const val EXTRA_SUCCESS = "extra_success"
        const val EXTRA_TOTAL_QUERIES = "extra_total_queries"

        private const val DEFAULT_QPM = 30
        private const val DEFAULT_JITTER_MS = 500L
        private const val ONE_MINUTE_MS = 60000L
        private const val MIN_DELAY_MS = 100L

        private const val CHANNEL_ID = "dqf_background_service"
        private const val NOTIFICATION_ID = 1
    }
}