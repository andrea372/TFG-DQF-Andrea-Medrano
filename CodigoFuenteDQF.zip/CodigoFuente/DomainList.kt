package com.tfg.dqfapp

object DomainList {

    private val domains = listOf(
        "google.com",
        "youtube.com",
        "facebook.com",
        "instagram.com",
        "x.com",
        "linkedin.com",
        "reddit.com",
        "wikipedia.org",
        "amazon.com",
        "amazon.es",
        "microsoft.com",
        "apple.com",
        "bing.com",
        "github.com",
        "netflix.com",
        "spotify.com",
        "wordpress.org",
        "whatsapp.com",
        "telegram.org",
        "icloud.com",
        "yahoo.com",
        "msn.com",
        "bbc.com",
        "cnn.com",
        "elpais.com",
        "elmundo.es",
        "abc.es",
        "lavanguardia.com",
        "rtve.es",
        "marca.com",
        "as.com",
        "stackoverflow.com",
        "mozilla.org",
        "adobe.com",
        "dropbox.com",
        "cloudflare.com",
        "zoom.us",
        "twitch.tv",
        "imdb.com",
        "archive.org"
    )

    fun getRandomDomain(): String {
        return domains.random()
    }

    fun getAllDomains(): List<String> {
        return domains
    }
}